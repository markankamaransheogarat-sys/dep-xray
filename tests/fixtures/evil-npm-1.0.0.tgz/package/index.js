module.exports = function ok() { return 42; };
